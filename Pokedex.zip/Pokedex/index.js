const express = require("express");
const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public'));


app.get("/", function(req, res){
    res.render("index");
});
app.get("/ConsultarCEP", function(req, res){
    res.render("consultarCEP");
});


app.listen(8181, function(erro){
    if (erro){
        console.log("Ocorreu um erro.");
    }else{
        console.log("Servidor iniciado.")
    }
});