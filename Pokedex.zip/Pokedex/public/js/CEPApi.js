function BuscarCEP(){
    let cep = $("#cep").val();
    
    if (validarCEP(cep, true)){
        $.getJSON("https://viacep.com.br/ws/"+ cep +"/json/?callback=?", function(dados){
            $("#cepInfo").val(dados.cep);
            $("#logradouroInfo").val(dados.logradouro);
            $("#complementoInfo").val(dados.complemento);
            $("#bairroInfo").val(dados.bairro);
            $("#localidadeInfo").val(dados.localidade);
            $("#ufInfo").val(dados.uf);
            $("#ibgeInfo").val(dados.ibge);
            $("#giaInfo").val(dados.gia);
            $("#dddInfo").val(dados.ddd);
            $("#siafiInfo").val(dados.siafi);
        });
    }
}

function validarCEP(cep, msg) {
    var validaCep = /^[0-9]{8}$/;
    if (!validaCep.test(cep))
    {
        $("#cep").attr("style", "float: left; text-transform:uppercase;border-color: red;");
        if (msg){
            alert("Formato de CEP inválido.");
        }
        return false;
    }
    else
    {
        $("#cep").attr("style", "float: left; text-transform:uppercase;");
    }
    return true;
};